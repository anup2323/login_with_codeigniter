
        
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <h2>Welcome to Admin Panel</h2>
                    </div>
                    
                </div>
				</div>
				</div>