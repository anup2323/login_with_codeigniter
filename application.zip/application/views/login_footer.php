<script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js');?>></script>
	<script src="<?php echo base_url('assets/js/popper.min.js');?>></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>></script>
    <script src="<?php echo base_url('assets/js/app.js');?>></script>
</body>
</html>