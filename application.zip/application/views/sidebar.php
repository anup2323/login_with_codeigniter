<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li class="active">
                            <a href="<?php echo site_url('dashboardController');?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li>
                            <a href="<?php echo site_url('StateController');?>"><i class=""></i> <span>State</span></a>
                        </li>
                       
                        <li>
                            <a href="<?php echo site_url('DistrictController');?>"><i class=""></i> <span>District</span></a>
                        </li>
						 <li class="submenu">
                            <a href="#"><i class=""></i> <span> Child Details </span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="<?php echo site_url('ChildController');?>">Child</a></li>
                            </ul>
                        </li>
                        
                       
						
                    </ul>
                </div>
            </div>
        </div>