<?php
if(empty($child_list)){
	$child_list = array();
}

?>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-7 col-6">
                        <h4 class="page-title">Child Profile</h4>
                    </div>

                    
                </div>
                <div class="card-box profile-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#"><img class="avatar" src="<?php echo base_url();?>uploads/<?php echo $child_list[0]['image'];?>" alt=""></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo $child_list[0]['child_name'];?></h3>
                                                <small class="text-muted">Sex : <?php echo $child_list[0]['gender'];?></small>
                                                <div class="staff-id">Dob : <?php echo $child_list[0]['dob'];?></div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <li>
                                                    <span class="title">Father Name:</span>
                                                    <span class="text"><?php echo $child_list[0]['father_name'];?></span>
                                                </li>
                                                <li>
                                                    <span class="title">Mother Name:</span>
                                                    <span class="text"><?php echo $child_list[0]['mother_name'];?></span>
                                                </li>
                                                <li>
                                                    <span class="title">State:</span>
                                                    <span class="text"><?php echo $child_list[0]['state_name'];?></span>
                                                </li>
                                                <li>
                                                    <span class="title">District:</span>
                                                    <span class="text"><?php echo $child_list[0]['district_name'];?></span>
                                                </li>
                                                <li>
                                                    <span class="title"></span>
                                                    <span class="text"></span>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
				