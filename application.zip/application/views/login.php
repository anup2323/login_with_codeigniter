
<body>
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
			
			<?php if(validation_errors() == TRUE){?>
				<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
							<?php echo validation_errors();?>
					</div>
				</div>
			<?php  }?>
			<?php 
			 $msg ='';
			if(!empty($this->session->flashdata('message_display'))){
				    $flashMsg = $this->session->flashdata('message_display');
					if(!empty($flashMsg['msg'])){
						$msg = $flashMsg['msg'];
						$color =$flashMsg['color'];
					}else{
						$msg = $this->session->flashdata('message_display');
						$color ='success';
					}
				?>
				<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo $color;?>" role="alert">
							<?php echo $msg;?>
					</div>
				</div>
			<?php  }?>
				<div class="account-box">
                    <form action="<?php echo site_url('LoginController/loginProcess')?>" method="post" class="login_frm" class="form-signin">
						<div class="account-logo">
                            <a href="index-2.html"><img src="assets/img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label>Username or Email</label>
                            <input type="text" autofocus="" class="form-control" name="username" id="username">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password"  id="password">
                        </div>
                      
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary account-btn">Login</button>
                        </div>
                        
                    </form>
                </div>
			</div>
        </div>
    </div>
    