
<body>
    <div class="main-wrapper  account-wrapper">
        <div class="account-page">
            <div class="account-center">
			<?php if(validation_errors() == TRUE){?>
				<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
							<?php echo validation_errors();?>
					</div>
				</div>
			<?php  }?>
                <div class="account-box">
                    <form action="<?php echo site_url('RegistrationController/regProcess')?>" method="post" id="frm_reg" class="form-signin">
						<div class="account-logo">
                            <a href="index-2.html"><img src="assets/img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" id="username" name="username">
                        </div>
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="form-group">
                            <label>Mobile Number</label>
                            <input type="phone" class="form-control" id="phone" name="phone">
                        </div>
                        <div class="form-group checkbox">
                            <label>
                                <input type="checkbox" id="term" name="term"> I have read and agree the Terms & Conditions
                            </label>
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-primary account-btn" type="submit">Signup</button>
                        </div>
                        <div class="text-center login-link">
                            Already have an account? <a href="<?php echo site_url('LoginController')?>">Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<script>
	$(document).ready(function(){
		alert("sfsf");
		setTimeout( "$('#account-box').hide();", 5000);
	 });
	</script>
    