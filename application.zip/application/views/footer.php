<div class="sidebar-overlay" data-reff=""></div>
	<script src="<?php echo base_url()?>assets/js/jquery-3.2.1.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url()?>assets/js/Chart.bundle.js"></script>
    <script src="<?php echo base_url()?>assets/js/app.js"></script>
	<script src="<?php echo base_url()?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/moment.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/bootstrap-datetimepicker.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url()?>assets/js/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url()?>assets/js/select2.min.js"></script>


</body>


<!-- index22:59-->
</html>