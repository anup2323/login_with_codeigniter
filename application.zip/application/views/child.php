<?php
if(empty($childlist)){
	$childlist =array();
}
?>
        <div class="page-wrapper">
            <div class="content">
			<?php if(validation_errors() == TRUE){?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
						<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
								<?php echo validation_errors();?>
						</div>
					</div>
				<?php  }
				    $msg ='';
					if(!empty($this->session->flashdata('message_display'))){
						$flashMsg = $this->session->flashdata('message_display');
						if(!empty($flashMsg['msg'])){
							$msg = $flashMsg['msg'];
							$color =$flashMsg['color'];
						}else{
							$msg = $this->session->flashdata('message_display');
							$color ='success';
						}
					?>
				<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo $color;?>" role="alert">
							<?php echo $msg;?>
					</div>
				</div>
			<?php  }?>
                <div class="row">
                    <div class="col-sm-5 col-5">
                        <h4 class="page-title">Child</h4>
                    </div>
                    <div class="col-sm-7 col-7 text-right m-b-30">
                        <a href="<?php echo site_url('ChildController/add_child');?>" class="btn btn-primary btn-rounded"><i class="fa fa-plus"></i> Add Child</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table mb-0 datatable">
                                <thead>
                                    <tr>
                                        
                                        <th>Name</th>
										<th>Gender</th>
										<th>Dob</th>
										<th>Father's Name</th>
										<th>Mother's Name</th>
										<th>State</th>
										<th>District</th>
										<th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
								
								<?php  
								if(!empty($childlist)){
								foreach($childlist as $childlist){?>
                                    <tr>
                                        <td><?php echo $childlist['child_name'];?></td>
                                        <td><?php echo $childlist['gender'];?></td>
										<td><?php echo $childlist['dob'];?></td>
										<td><?php echo $childlist['father_name'];?></td>
                                        <td><?php echo $childlist['mother_name'];?></td>
										<td><?php echo $childlist['state_name'];?></td>
										<td><?php echo $childlist['district_name'];?></td>
                                        <td><a href="<?php echo site_url('ChildController/profile/'.$childlist['id']);?>">View</a></td>
										
                                    </tr>
								<?php }}?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
    </div>
    