
        <div class="page-wrapper">
            <div class="content">
			<?php if(validation_errors() == TRUE){?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
						<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
								<?php echo validation_errors();?>
						</div>
					</div>
				<?php  }
				    $msg ='';
					if(!empty($this->session->flashdata('message_display'))){
						$flashMsg = $this->session->flashdata('message_display');
						if(!empty($flashMsg['msg'])){
							$msg = $flashMsg['msg'];
							$color =$flashMsg['color'];
						}else{
							 $msg = $this->session->flashdata('message_display');
							 $color ='success';  
						}?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo $color;?>" role="alert">
							<?php echo $msg;?>
					</div>
				</div>
			<?php  }?>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add State</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('StateController/addstateprocess');?>" id="add_state" class="add_state" method="post">
							<div class="form-group">
								<label>State Name</label>
								<input id="state_name" name="state_name" class="form-control" type="text" value="<?php echo set_value('state_name') ;?>">
							</div>
                            
                            <div class="m-t-20 text-center">
                                <button type="submit"  id="addstate" class="btn btn-primary submit-btn">Create State</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>
    </div>
    