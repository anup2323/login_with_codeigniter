<?php
if(empty($statelist)){
	$statelist =array();
}
?>
        <div class="page-wrapper">
            <div class="content">
			<?php if(validation_errors() == TRUE){?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
						<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
								<?php echo validation_errors();?>
						</div>
					</div>
				<?php  }
				    $msg ='';
					if(!empty($this->session->flashdata('message_display'))){
						$flashMsg = $this->session->flashdata('message_display');
						if(!empty($flashMsg['msg'])){
							$msg = $flashMsg['msg'];
							$color =$flashMsg['color'];
						}else{
							 $msg = $this->session->flashdata('message_display');
							 $color ='success';  
						}?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo $color;?>" role="alert">
							<?php echo $msg;?>
					</div>
				</div>
			<?php  }?>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add District</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 offset-lg-2">
                        <form action="<?php echo site_url('DistrictController/addistrictprocess');?>" id="add_state" class="add_state" method="post">
						<div class="col-sm-6">
									<div class="form-group">
										<label>Choose State</label>
										<select class="form-control select" name="state_id">
										    <?php foreach($statelist as $statelists){?>
											<option value="<?php echo $statelists['id'];?>"><?php echo $statelists['state_name'];?></option>
											<?php  } ?>
										</select>
									</div>
								</div>
							    <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>District</label>
                                        <input value="<?php echo set_value('district_name') ?>" class="form-control" type="text" name="district_name"  id="district_name">
                                    </div>
                                </div>
								
                            <div class="m-t-20 text-center">
                                <button type="submit"  id="addstate" class="btn btn-primary submit-btn">Create District</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>
    </div>
    