<?php
if(empty($statelist)){
	$statelist = array();
}
?>
        <div class="page-wrapper">
            <div class="content">
			<?php if(validation_errors() == TRUE){?>
					<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
						<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
								<?php echo validation_errors();?>
						</div>
					</div>
				<?php  }
				    $msg ='';
					if(!empty($this->session->flashdata('message_display'))){
						$flashMsg = $this->session->flashdata('message_display');
						if(!empty($flashMsg['msg'])){
							$msg = $flashMsg['msg'];
							$color =$flashMsg['color'];
						}else{
							$msg = $this->session->flashdata('message_display');
							$color ='success';
						}
					?>
				<div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo $color;?>" role="alert">
							<?php echo $msg;?>
					</div>
				</div>
			<?php  }
                if (isset($error)){?>
                    <div id="account-box" class="account-box" style="border:0"; "background-color:''";>
					<div class="account-center alert alert-<?php echo 'danger';?>" role="alert">
							<?php echo $error;?>
					</div>
					</div>
               <?php }
                  ?>
			
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Child</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('ChildController/addchildprocess')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Name <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="name">
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group gender-select">
										<label class="gen-label">Gender:</label>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input value="male" type="radio" name="gender" class="form-check-input">Male
											</label>
										</div>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input  value="female" type="radio" name="gender" class="form-check-input">Female
											</label>
										</div>
									</div>
                                </div>
                                
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Date of Birth</label>
                                        <div class="cal-icon">
                                            <input id="dob" name ="dob" type="text" class="form-control datetimepicker">
                                        </div>
                                    </div>
                                </div>
                                
								
										<div class="col-sm-6">
											<div class="form-group">
												<label>Father's Name</label>
												<input name="father_name" type="text" class="form-control ">
											</div>
										</div>
										
										
										<div class="col-sm-6">
											<div class="form-group">
												<label>Mother's Name</label>
												<input name="mother_name" type="text" class="form-control">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>State</label>
												<select id="state_id" name="state" class="form-control select">
													<option value="">Choose State</option>
													<?php foreach($statelist as $statelists){?>
														<option value="<?php echo $statelists['id'];?>"><?php echo $statelists['state_name'];?></option>
													<?php }
													?>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>District</label>
												<select name="dist" id="dist" class="form-control select">
													<option value="">Choose District</option>
													
												</select>
											</div>
										</div>
										
										<div class="col-sm-6">
									<div class="form-group">
										<label>Image</label>
										<div class="profile-upload">
											<div class="upload-img">
												<img alt="" src="assets/img/user.jpg">
											</div>
											<div class="upload-input">
												<input name="child_img" type="file" class="form-control">
											</div>
										</div>
									</div>
                                </div>	
										
									</div>
								</div>
                                
                                
                            </div>
                           
                            <div class="m-t-20 text-center">
                                <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
	<script>
	$(document).ready(function(){
		$("#state_id").change(function(){
			var current_state_id = $(this).val();
			var url ='<?php echo site_url('DistrictController/get_district');?>';
			if(current_state_id !=''){
				$.ajax({
                    url: url,
                    type: "POST",
                    async: false,
                    data: { 'state_id': current_state_id},
                    success: function(res){
						if(res != null){
							$("#dist").html(res);
						}else{
							$("#dist").html('<option value="">No Records found</option>');
						}
                    }
                });
			}
			
		});
	});
	</script>
    