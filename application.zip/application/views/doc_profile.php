<?php 
$first_name = '';
$last_name = '';
$gender = '';
$specilization = '';
$department_id = '';
$phone = '';
$email = '';
$address ='';
$city = '';
$distt = '';
$state = '';
$pincode = '';
$country ='';
$biography ='';
$updated_on = '';
$status = '';
$depatmen_name ='';


if(!empty($doctorList)){
$docId = $doctorList[0]['id'];
$first_name = $doctorList[0]['first_name'];
$last_name = $doctorList[0]['last_name'];
$gender = $doctorList[0]['gender'];
$specilization = $doctorList[0]['specilization'];
$department_id = $doctorList[0]['department_id']; 
$phone = $doctorList[0]['mobile'];
$email = $doctorList[0]['email'];
$address = $doctorList[0]['address'];
$city = $doctorList[0]['city'];
$distt = $doctorList[0]['district'];
$state = $doctorList[0]['state'];
$pincode = $doctorList[0]['pincode'];
$country = $doctorList[0]['country'];
$biography = $doctorList[0]['biography'];
$updated_on = $doctorList[0]['updated_on'];
$status = $doctorList[0]['status'];
$this ->db-> select('*');
$this -> db -> from('department');
$this -> db -> where('id',$department_id);
$this -> db -> where('status','1');
$query = $this -> db -> get();
$res= $query -> num_rows();
	if($res  > 0){
		$result = $query->result_array();
		$depatmen_name = $result[0]['depatmen_name'];
	}else{
		$depatmen_name ='';
	}
}else{
	 $doctorList =array();
	 $docId = $this->uri->segment(1); 
}
?>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-7 col-6">
                        <h4 class="page-title">My Profile</h4>
                    </div>

                    <div class="col-sm-5 col-6 text-right m-b-30">
                        <a href="<?php echo site_url('doctorController/docEdit/'.$docId);?>" class="btn btn-primary btn-rounded"><i class="fa fa-plus"></i> Edit Profile</a>
                    </div>
                </div>
                <div class="card-box profile-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#"><img class="avatar" src="assets/img/doctor-03.jpg" alt=""></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo ucwords($first_name.' '.$last_name);?></h3>
                                                <small class="text-muted"><?php echo ucwords($depatmen_name);?></small>
                                                <div class="staff-id">Employee ID : DR-00<?php echo ucwords($docId);?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <li>
                                                    <span class="title">Phone:</span>
                                                    <span class="text"><a href="#"><?php echo $phone;?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Email:</span>
                                                    <span class="text"><a href="#"><?php echo $email;?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Specilization:</span>
                                                    <span class="text"><?php echo ucwords($specilization);?></span>
                                                </li>
                                                <li>
                                                    <span class="title">Address:</span>
                                                    <span class="text"><?php echo $address;?></span>
                                                </li>
                                                <li>
                                                    <span class="title">Gender:</span>
                                                    <span class="text"><?php echo $gender;?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
				
            </div>
        </div>
    </div>
    