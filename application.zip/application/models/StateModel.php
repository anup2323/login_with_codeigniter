<?php 
   class StateModel extends CI_Model 
   { 
		public function __construct()
		{ 
			parent::__construct(); 
			//$this->load->database();
		}
		public function savestate($data){
			$result=$this->db->insert('state', $data);
			if($result == true){
				return true;
			}else{
				return false;
			}
		}
		
		function checkstateExist($state)
		{
		   $this ->db-> select('*');
		   $this -> db -> from('state');
		   $this -> db -> where('lower(state_name)', strtolower($state));
		   $query = $this -> db -> get();
		   $res= $query -> num_rows();
		   if($res  > 0){
			return true;  
		   } else {
			 return false;
		   }
		}
		function getlist()
		{
		   $this ->db-> select('*');
		   $this -> db -> from('state');
		   $query = $this -> db -> get();
		   $res= $query -> num_rows();
		   if($res  > 0){
			return $query->result_array();  
		   } else {
			 return false;
		   }
		}
		
   } 
?>