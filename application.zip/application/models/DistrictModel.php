<?php 
   class DistrictModel extends CI_Model 
   { 
		public function __construct()
		{ 
			parent::__construct(); 
			//$this->load->database();
		}
		public function savedist($data){
			$result=$this->db->insert('district', $data);
			if($result == true){
				return true;
			}else{
				return false;
			}
		}
		
		
		function getlist()
		{
		   $this ->db-> select('*');
		   $this -> db -> from('district');
		   $query = $this -> db -> get();
		   $res= $query -> num_rows();
		   if($res  > 0){
			return $query->result_array();  
		   } else {
			 return false;
		   }
		}
		function getdistlist($state_id)
		{
		   $this ->db-> select('*');
		   $this -> db -> from('district');
		    $this -> db -> where('state_id',$state_id);
		   $query = $this -> db -> get();
		   $res= $query -> num_rows();
		   if($res  > 0){
			return $query->result_array();  
		   } else {
			 return false;
		   }
		}
		
   } 
?>