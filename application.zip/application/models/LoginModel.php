<?php 
   class LoginModel extends CI_Model 
   { 
		public function __construct()
		{ 
			parent::__construct(); 
			//$this->load->database();
		}
		
		function checkLogin( $data)
		{
			$username= $data['username'];
			$password= $data['password'];
			$this->db->select('*');
			$this->db -> from('admin');
		   $this->db-> where('username', $username);
		   $this->db-> where('password', $password);
		   $query = $this -> db -> get();
		   $res= $query -> num_rows();
		   if($res  > 0){
			return $query->result_array();  
		   } else {
			 return false;
		   }
		}
     	  
   } 
?>