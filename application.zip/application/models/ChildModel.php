<?php 
   class ChildModel extends CI_Model 
   { 
		public function __construct()
		{ 
			parent::__construct(); 
			//$this->load->database();
		}
		public function savedata($data){
			$result=$this->db->insert('child_details', $data);
			if($result == true){
				return true;
			}else{
				return false;
			}
		}
		
		
		function getlist()
		{
		  
			$sql ="select image,id ,child_name,dob,gender,father_name,mother_name,(select state_name from state where id=state_id)as state_name  ,(select district_name from district where id=district_id)as district_name  from child_details";
			$query = $this->db->query($sql);
			$res= $query -> num_rows();
			if($res  > 0){
				 return $query->result_array();  
			} else {
				 return null;
			}
		}
		public function getchildlist($child_id=null){
			$sql ="select image,id ,child_name,dob,gender,father_name,mother_name,(select state_name from state where id=state_id)as state_name  ,(select district_name from district where id=district_id)as district_name  from child_details where id ='$child_id'";
			$query = $this->db->query($sql);
			$res= $query -> num_rows();
			if($res  > 0){
				 return $query->result_array();  
			} else {
				 return null;
			}
		}
		
		
   } 
?>