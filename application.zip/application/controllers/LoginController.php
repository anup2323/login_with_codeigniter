<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('LoginModel');
	$this->load->helper('url','form','html');
	$this->load->library('form_validation');
	$this->load->library('session');
  }
  function index(){
	$this->load->view('login_head');
    $this->load->view('login');
	$this->load->view('login_footer');
  }
   public function loginProcess(){
	  // Check validation for user input in SignUp form
	$this->form_validation->set_rules('username', 'Enter Username', 'trim|required');
	$this->form_validation->set_rules('password', 'Enter Password', 'trim|required');
	if ($this->form_validation->run() == FALSE) {
		$this->load->view('login_head');
		$this->load->view('login');
		$this->load->view('login_footer');
	}else {
		$data = array(
		'username' => $this->input->post('username'),
		'password' => $this->input->post('password'),
		);
		
		
		$result = $this->LoginModel->checkLogin($data);  
		if ($result == TRUE) {
			// Add user data in session
			$session_data = $result;  
			$this->session->set_userdata('logged_in',$session_data);
			$data['message_display'] = 'Login Successfully !';
			redirect('/DashboardController');
			exit;
		} else {
			$flastDataArray= array(
			'msg'=>'Invalid Username or Password!',
			'color'=>'danger',
			);
			$this->session->set_flashdata('message_display',$flastDataArray);
			redirect('/LoginController','refresh');
		}
	}
	
  }
  // logout function
  public function logout(){
	$this->session->unset_userdata('logged_in');
	$this->session->sess_destroy();
	redirect('/LoginController','refresh');
	exit;
  }
  
}
