<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DistrictController extends CI_Controller{
  function __construct(){
    parent::__construct();
	$this->load->model('StateModel');
	$this->load->model('DistrictModel');
    $this->load->helper('security');
	$this->load->helper('url','form','html');
	$this->load->library('form_validation');
	
	
  }
  function index(){
	$distlist = $this->DistrictModel->getlist();
	$this->load->view('header');
	$this->load->view('sidebar');
	if(!empty($distlist)){
		$this->load->view('dist',array('distlist'=>$distlist));
	}else{
		$this->load->view('dist');
	}
	$this->load->view('footer');
	
  }
  function addistrictprocess(){
	  
	$this->form_validation->set_rules('state_id', 'Choose state', 'trim|required');
	$this->form_validation->set_rules('district_name', 'Enter district', 'trim|required');
	if ($this->form_validation->run() == FALSE) {
		
		$this->load->view('header');
	    $this->load->view('sidebar');
		 $this->load->view('add-dist');
		 $this->load->view('footer');
	}else {
		$data = array(
		'state_id' => $this->input->post('state_id'),
		'district_name' => $this->input->post('district_name')
		);
		
		$result = $this->DistrictModel->savedist($data);
		
		if ($result == TRUE) {
			$this->session->set_flashdata('message_display','State added Successfully !');
			redirect('/DistrictController');
			exit;
		} else {
			$this->session->set_flashdata('message_display','Something went wrong!');
			redirect('/DistrictController/add_district');
			exit;
			
		}
	}
	
  }
  
  function add_district(){
	$statelist = $this->StateModel->getlist();
	$this->load->view('header');
	$this->load->view('sidebar');
	if(!empty($statelist)){
		$this->load->view('add-dist',array('statelist'=>$statelist));
	}else{
		$this->load->view('add-dist');
	}
	$this->load->view('footer');
	
  }
  function get_district(){
	$state_id = $this->input->post('state_id');
	if(!empty($state_id)){
		$list=$this->DistrictModel->getdistlist($state_id);
		echo '<option value="">Choose District</option>';
		foreach($list as  $lists){?>
		<option value="<?php echo $lists['id'];?>"><?php echo  $lists['district_name'];?> </option>
	 <?php } 
	}else{
		echo null;
	}
	
  }
  
  
   
}
