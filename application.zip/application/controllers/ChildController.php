<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ChildController extends CI_Controller{
  function __construct(){
    parent::__construct();
	$this->load->model('ChildModel');
	$this->load->model('StateModel');
    //$this->load->helper('security');
	$this->load->helper('url','form','html');
	$this->load->library('form_validation');
	
	
  }
  function index(){
	$childlist = $this->ChildModel->getlist();
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('child',array('childlist'=>$childlist));
	$this->load->view('footer');
	
  }
  function addchildprocess(){
	  
	$this->form_validation->set_rules('name', 'Enter name', 'trim|required');
	$this->form_validation->set_rules('gender', 'Choose gender', 'trim|required');
	$this->form_validation->set_rules('dob', 'Choose  Date of birth', 'trim|required');
	$this->form_validation->set_rules('father_name', 'Enter father name', 'trim|required');
	$this->form_validation->set_rules('mother_name', 'Enter mother name', 'trim|required');
	$this->form_validation->set_rules('state', 'Choose state', 'trim|required');
	$this->form_validation->set_rules('dist', 'Choose district', 'trim|required');
	if ($this->form_validation->run() == FALSE) {
		echo "i m here";  die;
		$this->load->view('header');
	    $this->load->view('sidebar');
		 $this->load->view('add-child');
		 $this->load->view('footer');
	}else {
		
		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|png';
        $config['max_size'] = 2000;
        $config['max_width'] = 1500;
        $config['max_height'] = 1500;
		$this->load->library('upload', $config);
		
		if (!$this->upload->do_upload('child_img')) {
            $error = array('error' => $this->upload->display_errors());
			$this->load->view('header');
	    $this->load->view('sidebar');
            $this->load->view('add-child', $error);
			$this->load->view('footer');
        } else {
            $uploaddata = array('image_metadata' => $this->upload->data());
            $filename = $uploaddata['image_metadata']['file_name'];
			//echo "<pre>"; print_r($uploaddata);die;
			$data = array(
			'child_name' => $this->input->post('name'),
			'gender' => $this->input->post('gender'),
			'dob' => $this->input->post('dob'),
			'father_name' => $this->input->post('father_name'),
			'mother_name' => $this->input->post('mother_name'),
			'state_id' => $this->input->post('state'),
			'district_id' => $this->input->post('dist'),
			'image' => $filename,
			);
			$result = $this->ChildModel->savedata($data);
			if ($result == TRUE) {
				$this->session->set_flashdata('message_display','Child added Successfully !');
				redirect('/ChildController');
				exit;
			} else {
				$this->session->set_flashdata('message_display','Something went wrong!');
				redirect('/ChildController/add_child');
				exit;
				
			}
        }
	}
	
  }
  
  
  function add_child(){
	$statelist = $this->StateModel->getlist();
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('add-child',array('statelist' => $statelist));
	$this->load->view('footer');
	
  }
  function profile($id){
	$child_list = $this->ChildModel->getchildlist($id);
	
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('profile',array('child_list' => $child_list));
	$this->load->view('footer');
	
  }
  
  
   
}
