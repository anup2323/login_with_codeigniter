<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class DashboardController extends CI_Controller{
  function __construct(){
    parent::__construct();
    //$this->load->model('RegistrationModel');
	$this->load->database();
	$this->load->helper(array('url', 'form', 'html','security'));
	$this->load->library('form_validation');
	
  }
  function index(){
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('dashboard');
	$this->load->view('footer');
  }
   
}
