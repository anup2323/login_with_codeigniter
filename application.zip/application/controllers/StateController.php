<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StateController extends CI_Controller{
  function __construct(){
    parent::__construct();
	$this->load->model('StateModel');
    $this->load->helper('security');
	$this->load->helper('url','form','html');
	$this->load->library('form_validation');
	
	
  }
  function index(){
	$statelist = $this->StateModel->getlist();
	
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('state',array('statelist'=>$statelist));
	$this->load->view('footer');
	
  }
  function addstateprocess(){
	  
	$this->form_validation->set_rules('state_name', 'Enter state', 'trim|required|callback_stateName');
	if ($this->form_validation->run() == FALSE) {
		
		$this->load->view('header');
	    $this->load->view('sidebar');
		 $this->load->view('add-state');
		 $this->load->view('footer');
	}else {
		$data = array(
		'state_name' => $this->input->post('state_name')
		);
		
		$result = $this->StateModel->savestate($data);
		
		if ($result == TRUE) {
			$this->session->set_flashdata('message_display','State added Successfully !');
			redirect('/StateController');
			exit;
		} else {
			$this->session->set_flashdata('message_display','Something went wrong!');
			redirect('/StateController/add_state');
			exit;
			
		}
	}
	
  }
  function stateName($state_name){
		if ($this->StateModel->checkstateExist($state_name) == false) {
			return true;
		} else {
			$this->form_validation->set_message('stateName', 'This State already exist!');
			return FALSE;
		}
	}
  
  function add_state(){
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('add-state');
	$this->load->view('footer');
	
  }
  
  function get_district(){
	$this->load->view('header');
	$this->load->view('sidebar');
    $this->load->view('add-state');
	$this->load->view('footer');
	
  }
  
  
   
}
